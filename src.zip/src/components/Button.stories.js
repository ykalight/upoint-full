import React from 'react';
import { withKnobs, boolean, select, text } from '@storybook/addon-knobs';
import { action } from '@storybook/addon-actions';
import { withDesign } from 'storybook-addon-designs'

import Button from './Button';

// This story is written in "Component Story Format" that was introduced in Storybook 5.2
// https://storybook.js.org/docs/formats/component-story-format/
export default {
  title: 'Button',
  parameters: {
    component: Button,
    decorators: [withKnobs, withDesign],
    // Module-Level 'in-dsm' configuration (Will apply to all stories inside the module)
    'in-dsm': { id: '5fffb7b1d56120c768cd304b', versionFilePath: '../components/versionFile.json' }
  }
};

const iconOptions = { none: null, 'chevron-right': 'chevron-right', 'plus': '+' };

export const simpleButton = () => (
  <Button
    onClick={() => action('Button clicked')('Click')}
    icon={select('icon', iconOptions, iconOptions.none)}
    disabled={boolean('disabled', false)}
  >
    {text('children', 'Yo, Figma here!')}
  </Button>
);

simpleButton.story = {
  parameters: {
    design: {
      type: 'figma',
      url: 'https://www.figma.com/file/1Dr4rUfVw1IKsXoKbxyaJ0/Alight-%E2%80%93-Project-Tiger-Team-Library?node-id=385%3A65'
      // 'in-dsm': { id: '5fffb7b1d56120c768cd304b' } 
    }
  }
}
