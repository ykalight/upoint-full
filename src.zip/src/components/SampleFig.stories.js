// import { withDesign } from 'storybook-addon-designs'

// export default {
//   title: 'Sample Figma YK',
//   component: Button,
//   decorators: [withDesign],
// }

// export const myStory = () => <Button>Yo, Figma here!</Button>

// myStory.parameters = {
//   design: {
//     type: 'figma',
//     url: 'https://www.figma.com/embed?embed_host=share&url=https%3A%2F%2Fwww.figma.com%2Ffile%2F1Dr4rUfVw1IKsXoKbxyaJ0%2FAlight-%25E2%2580%2593-Project-Tiger-Team-Library%3Fnode-id%3D332%253A75',
//     'in-dsm': { id: '600b19a370f5bb3a298f9e88' }
//   },
// }